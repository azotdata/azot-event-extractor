"""
This script contains class definition of the scraping and storage of newspapers
"""

import logging

from models import *
from newspaper import Article as NpArticle
from newspaper import Source as NpSource
from utils import get_http_response


class CollectArticle():
    """
    Class for articles extraction by source news.
    Scraps and stores them in database
    """
    def __init__(self):
        pass

    # method called while instantiate CollectArticle object in order to scrap a source news
    def extract_from_source(self,source,lang='fr'):
        news = NpSource(source, verbose = True)
        news.clean_memo_cache()
        news.build()
        logging.info('...build done!')

        for url in news.article_urls():
            if self.is_available_url(url):
                article = self.extract_articles(url,lang)
                if self.is_available_article(article):
                    self.store_structured_article(article)

    # calls newspaper Article class to scrap an article
    @staticmethod
    def extract_articles(url,lang):
        article = NpArticle(url,lang,fetch_images=False,memoize_articles=False)
        article.download()
        article.parse()
        return article

    # checks if the article already exists in our database. If yes, check the link if available or not
    @staticmethod
    def is_available_url(url):
        # function get_http_response is defined in utils.py, and checks whether the page is available or not found
        http_resp = get_http_response(url)
        logging.info('HTTP response %s' % http_resp)

        # here we check if url already exists or not, if not we continue
        if not Article.objects(source=url):
            if http_resp is True:
                return True

    @staticmethod
    def is_available_article(article):
        if article.text != "":
            if "LINFO" not in article.text:
                return True

    # stores the article datas in Article collection
    @staticmethod
    def store_structured_article(article):
        structured_article=Article()
        structured_article.id=ObjectId()
        structured_article.set_article(article)
        structured_article.save()
        logging.info('Datas successfully saved for the article whose link is %s! NEXT?' % article.url)
