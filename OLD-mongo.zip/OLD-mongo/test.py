from __future__ import unicode_literals

from mongoengine import connect
from ConfigParser import SafeConfigParser
from scraping_newspapers import *
from models import Article

# Reading Config file
config = SafeConfigParser()
config.read('../config.ini')

# Connect to the DB
connect(config.get('database', 'name'))

#Article.objects(source="https://www.clicanoo.re/AFP/Article/2017/06/11/Au-G7-Environnement-six-pays-unis-et-une-presence-americaine-furtive_473347#disqus_thread")
if Article.objects(source="https://www.clicanoo.re/AFP/Article/2017/06/11/Au-G7-Environnement-six-pays-unis-et-une-presence-americaine-furtive_473347#disqus_thread"):
    print("non vide")